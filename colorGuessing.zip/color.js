var myColor = parseInt(document.getElementById("myColorGuess").value);

// ------------------------------------------------------------------------------------
// test to see if the button has been clicked then run the code for the guessing game
// ------------------------------------------------------------------------------------

document.getElementById("runTest").onclick = function() {

  myColor = parseInt(document.getElementById("myColorGuess").value);

// store the random number between 1 and 3
// red = 1
// orange = 2
// yellow = 3


var theCorrectColor // color name matched with number

var theColor = (Math.floor(Math.random() * 3) + 1);

//alert("The user picked "+myColor);
//alert("The computer picked "+theColor);

if (theColor==1) {  // test for red
  theCorrectColor = "Red";
  // the computer picked the color red
  document.getElementById("colorReturned").style.display = "block";
  document.getElementById("colorReturned").style.backgroundColor = "red";

  if (theColor==myColor) {
  alert("You're Correct! The Color was "+theCorrectColor);
  }
  else {
  alert("Sorry! You're wrong! The correct Color was "+theCorrectColor);
  }
}

else if (theColor==2) { // test for orange
  theCorrectColor = "Orange";
  // the computer picked the color orange
  document.getElementById("colorReturned").style.display = "block";
  document.getElementById("colorReturned").style.backgroundColor = "orange";

  if (theColor==myColor) {
  alert("You're Correct! The Color was "+theCorrectColor);
  }
  else {
  alert("Sorry! You're wrong! The correct Color was "+theCorrectColor);
  }
}

else { // test for yellow
  theCorrectColor = "Yellow";
  // the computer picked the color yellow
  document.getElementById("colorReturned").style.display = "block";
  document.getElementById("colorReturned").style.backgroundColor = "yellow";

  if (theColor==myColor) {
  alert("You're Correct! The Color was "+theCorrectColor);
  }
  else {
  alert("Sorry! You're wrong! The correct Color was "+theCorrectColor);
  }
}

}
